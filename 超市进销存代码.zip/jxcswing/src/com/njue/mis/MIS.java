package com.njue.mis;
import javax.swing.JFrame;

import com.njue.mis.view.LoginFrame;

public class MIS
{
	public static void main(String[] args)
	{
		JFrame.setDefaultLookAndFeelDecorated(true);
		@SuppressWarnings("unused")
		LoginFrame loginFrame=new LoginFrame();
		JFrame.setDefaultLookAndFeelDecorated(true);
	}
}