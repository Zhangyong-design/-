/**
 * ������
 */
package com.njue.mis.model;



public class PortIn extends Port
{

	public PortIn()
	{
		super();
	}

	public PortIn(String id, String providerId, String goodsId, String payType,
			int number, double price, String time, String operatePerson,
			String comment)
	{
		super(id, providerId, goodsId, payType, number, price, time, operatePerson,
				comment);
		// TODO Auto-generated constructor stub
	}

}
